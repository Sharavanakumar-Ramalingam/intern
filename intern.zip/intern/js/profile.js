$(document).ready(function() {
    var username = localStorage.getItem('username');
    if (!username) {
        window.location.href = 'login.html';
    } else {
        $('#displayUsername').text(username);
    }

    $.ajax({
        url: 'php/get_profile.php',
        method: 'POST',
        data: { username: username },
        success: function(response) {
            var profile = JSON.parse(response);
            $('#age').val(profile.age);
            $('#dob').val(profile.dob);
            $('#contact').val(profile.contact);
        }
    });

    $('#profileForm').on('submit', function(event) {
        event.preventDefault();
        var age = $('#age').val();
        var dob = $('#dob').val();
        var contact = $('#contact').val();

        $.ajax({
            url: 'php/update_profile.php',
            method: 'POST',
            data: {
                username: username,
                age: age,
                dob: dob,
                contact: contact
            },
            success: function(response) {
                if (response == 'success') {
                    alert('Profile updated successfully!');
                } else {
                    alert('Error: ' + response);
                }
            }
        });
    });
});
