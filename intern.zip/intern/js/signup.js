$(document).ready(function() {
    $('#signupForm').on('submit', function(event) {
        event.preventDefault();
        var username = $('#username').val();
        var password = $('#password').val();
        var valid = true;

        if (password.length < 8) {
            $('#passwordError').text('Password must be at least 8 characters long');
            valid = false;
        } else {
            $('#passwordError').text('');
        }

        if (valid) {
            $.ajax({
                url: 'php/signup.php',
                method: 'POST',
                data: {
                    username: username,
                    password: password
                },
                success: function(response) {
                    if (response == 'username_exists') {
                        $('#usernameError').text('Username already exists');
                    } else if (response == 'success') {
                        alert('Signup successful!');
                        window.location.href = 'login.html';
                    } else {
                        alert('Error: ' + response);
                    }
                }
            });
        }
    });
});
