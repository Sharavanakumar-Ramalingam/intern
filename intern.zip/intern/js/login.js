$(document).ready(function() {
    $('#loginForm').on('submit', function(event) {
        event.preventDefault();
        var username = $('#username').val();
        var password = $('#password').val();

        $.ajax({
            url: 'php/login.php',
            method: 'POST',
            data: {
                username: username,
                password: password
            },
            success: function(response) {
                if (response == 'success') {
                    localStorage.setItem('username', username);
                    window.location.href = 'profile.html';
                } else {
                    alert('Invalid username or password');
                }
            }
        });
    });
});
