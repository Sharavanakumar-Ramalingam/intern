<?php
include 'db_config.php';

$username = $_POST['username'];
$age = $_POST['age'];
$dob = $_POST['dob'];
$contact = $_POST['contact'];

$profile_collection = $mongo_db->profiles;
$profile = [
    'username' => $username,
    'age' => $age,
    'dob' => $dob,
    'contact' => $contact
];

$profile_collection->updateOne(
    ['username' => $username],
    ['$set' => $profile],
    ['upsert' => true]
);

echo 'success';
?>
