<?php
include 'db_config.php';

$username = $_POST['username'];
$profile_collection = $mongo_db->profiles;

$profile = $profile_collection->findOne(['username' => $username]);

if ($profile) {
    echo json_encode($profile);
} else {
    echo json_encode(['username' => $username, 'age' => '', 'dob' => '', 'contact' => '']);
}
?>
