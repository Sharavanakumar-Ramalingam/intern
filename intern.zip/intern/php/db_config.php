<?php
require '../vendor/autoload.php'; 

$mysql_host = 'localhost';
$mysql_user = 'root';
$mysql_pass = ''; 
$mysql_db = 'user_db';

$mysqli = new mysqli($mysql_host, $mysql_user, $mysql_pass, $mysql_db);

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

$mongo_client = new MongoDB\Client("mongodb://localhost:27017");
$mongo_db = $mongo_client->user_profiles;
?>
