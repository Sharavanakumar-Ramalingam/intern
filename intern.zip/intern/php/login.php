<?php
include 'db_config.php';

$username = $_POST['username'];
$password = $_POST['password'];

$stmt = $mysqli->prepare("SELECT password FROM users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        echo 'success';
    } else {
        echo 'error';
    }
} else {
    echo 'error';
}

$stmt->close();
$mysqli->close();
?>
