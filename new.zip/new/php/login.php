<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require '../vendor/autoload.php';

try {
    $redis = new Predis\Client();

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
        if (!$stmt) {
            throw new Exception("Prepare statement failed: " . $conn->error);
        }

        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $session_token = bin2hex(random_bytes(32));

            $redis->set($session_token, $username);
            $redis->expire($session_token, 3600);

            if ($redis->exists($session_token)) {
                echo json_encode(['status' => 'success', 'session_token' => $session_token, 'username' => $username]);
            } else {
                throw new Exception("Failed to set session token in Redis");
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
        }

        $stmt->close();
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}

$conn->close();
?>
