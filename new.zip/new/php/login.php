<?php
require 'redis_connect.php'; // Include the Redis connection script

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
        // Generate a session token
        $session_token = bin2hex(random_bytes(32));

        // Store session token in Redis
        $redis->set($session_token, $username);
        $redis->expire($session_token, 3600); // Set expiry time to 1 hour

        echo json_encode(['status' => 'success', 'session_token' => $session_token, 'username' => $username]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
    }

    $stmt->close();
}

$conn->close();
?>
