<?php
require '../vendor/autoload.php';

$redis = new Predis\Client();

if (isset($_POST['session_token'])) {
    $session_token = $_POST['session_token'];

    if ($redis->exists($session_token)) {
        $username = $redis->get($session_token);
        $profile_key = "profile:$username";

        if ($redis->exists($profile_key)) {
            $profile = $redis->hgetall($profile_key);
            echo json_encode(['status' => 'success', 'profile' => $profile]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Profile not found']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid session token']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Session token not provided']);
}
?>
