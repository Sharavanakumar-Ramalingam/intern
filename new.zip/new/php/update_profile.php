<?php
require '../vendor/autoload.php';

$redis = new Predis\Client();

if (isset($_POST['session_token']) && isset($_POST['age']) && isset($_POST['dob']) && isset($_POST['contact'])) {
    $session_token = $_POST['session_token'];
    $age = $_POST['age'];
    $dob = $_POST['dob'];
    $contact = $_POST['contact'];

    if ($redis->exists($session_token)) {
        $username = $redis->get($session_token);
        $profile_key = "profile:$username";

        // Delete the previous values
        $redis->del($profile_key);

        // Set the new values
        $redis->hmset($profile_key, [
            'username' => $username,
            'age' => $age,
            'dob' => $dob,
            'contact' => $contact
        ]);

        echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid session token']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Required fields not provided']);
}
?>
