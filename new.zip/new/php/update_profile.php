<?php
require 'redis_connect.php'; // Include the Redis connection script
require '../vendor/autoload.php'; // Ensure you've installed the MongoDB client via Composer

$client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $client->user_db->profiles;

if (isset($_POST['session_token'])) {
    $session_token = $_POST['session_token'];
    $username = $redis->get($session_token);

    if ($username) {
        $age = $_POST['age'];
        $dob = $_POST['dob'];
        $contact = $_POST['contact'];

        $result = $collection->updateOne(
            ['username' => $username],
            ['$set' => ['age' => $age, 'dob' => $dob, 'contact' => $contact]],
            ['upsert' => true]
        );

        if ($result->getModifiedCount() > 0 || $result->getUpsertedCount() > 0) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No changes made']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid session']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No session token provided']);
}
?>
