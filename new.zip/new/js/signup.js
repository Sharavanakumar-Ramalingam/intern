$(document).ready(function() {
    $("#username").on("blur", function() {
        let username = $(this).val();
        if (username.length > 0) {
            $.ajax({
                url: 'php/check_username.php',
                type: 'POST',
                data: {username: username},
                success: function(response) {
                    if (response === 'exists') {
                        $("#usernameHelp").text("Username already exists").css("color", "red");
                    } else {
                        $("#usernameHelp").text("");
                    }
                }
            });
        }
    });

    $("#signupForm").on("submit", function(e) {
        e.preventDefault();
        let password = $("#password").val();
        let passwordHelp = $("#passwordHelp");

        if (password.length < 8 || !/\d/.test(password) || !/[a-zA-Z]/.test(password)) {
            passwordHelp.text("Password must be at least 8 characters long and contain both letters and numbers.").css("color", "red");
        } else {
            passwordHelp.text("");
            $.ajax({
                url: 'php/register.php',
                type: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    if (response === 'success') {
                        alert("Registration successful!");
                        window.location.href = 'login.html';
                    } else {
                        alert("Registration failed. Try again.");
                    }
                }
            });
        }
    });
});
