$(document).ready(function() {
    let sessionToken = localStorage.getItem('session_token');

    if (!sessionToken) {
        window.location.href = 'login.html';
    }

    $("#profileForm").on("submit", function(e) {
        e.preventDefault();
        let formData = $(this).serialize() + '&session_token=' + sessionToken;
        $.ajax({
            url: 'php/update_profile.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.status === 'success') {
                    alert("Profile updated successfully!");
                } else {
                    alert("Profile updated successfully!");
                }
            }
        });
    });
});
