$(document).ready(function() {
    var sessionToken = localStorage.getItem('session_token');
    var username = localStorage.getItem('username');

    if (!sessionToken || !username) {
        alert('You need to log in first.');
        window.location.href = 'login.html';
    }

    // Fetch and display the profile data
    $.ajax({
        type: 'POST',
        url: 'get_profile.php',
        data: { session_token: sessionToken },
        success: function(response) {
            var data = JSON.parse(response);
            if (data.status === 'success') {
                $('#welcomeMessage').text('Welcome, ' + data.profile.username);
                $('#age').val(data.profile.age);
                $('#dob').val(data.profile.dob);
                $('#contact').val(data.profile.contact);
            } else {
                alert(data.message);
            }
        }
    });

    // Handle profile update
    $('#profileForm').submit(function(e) {
        e.preventDefault();
        var age = $('#age').val();
        var dob = $('#dob').val();
        var contact = $('#contact').val();

        $.ajax({
            type: 'POST',
            url: 'update_profile.php',
            data: {
                session_token: sessionToken,
                age: age,
                dob: dob,
                contact: contact
            },
            success: function(response) {
                var data = JSON.parse(response);
                if (data.status === 'success') {
                    alert('Profile updated successfully.');
                } else {
                    alert(data.message);
                }
            }
        });
    });
});
