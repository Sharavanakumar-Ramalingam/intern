$(document).ready(function() {
    // Login Form
    $("#loginForm").on("submit", function(e) {
        e.preventDefault();
        $.ajax({
            url: 'php/login.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                let res = JSON.parse(response);
                if (res.status === 'success') {
                    localStorage.setItem('session_token', res.session_token);
                    localStorage.setItem('username', res.username);
                    alert("Login successful!");
                    window.location.href = 'profile.html';
                } else {
                    alert("Invalid login credentials. Try again.");
                }
            }
        });
    });

    // Profile Page
    if (window.location.pathname.endsWith("profile.html")) {
        let sessionToken = localStorage.getItem('session_token');
        let username = localStorage.getItem('username');

        if (!sessionToken || !username) {
            window.location.href = 'login.html';
        } else {
            $("#welcomeMessage").text(`Welcome, ${username}!`);
        }

        $("#profileForm").on("submit", function(e) {
            e.preventDefault();
            let formData = $(this).serialize() + '&session_token=' + sessionToken;
            $.ajax({
                url: 'php/update_profile.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    let res = JSON.parse(response);
                    if (res.status === 'success') {
                        alert("Profile updated successfully!");
                    } else {
                        alert("Profile updated successfully!");
                    }
                }
            });
        });
    }
});
