$(document).ready(function() {
    $('#loginForm').submit(function(e) {
        e.preventDefault();
        var username = $('#username').val();
        var password = $('#password').val();

        $.ajax({
            type: 'POST',
            url: 'login.php',
            data: {
                username: username,
                password: password
            },
            success: function(response) {
                try {
                    var data = JSON.parse(response);
                    if (data.status === 'success') {
                        localStorage.setItem('session_token', data.session_token);
                        localStorage.setItem('username', data.username);
                        window.location.href = 'profile.html';
                    } else {
                        alert(data.message);
                    }
                } catch (e) {
                    console.error('Parsing error:', e);
                    console.log('Server response:', response);
                    alert('An error occurred. Check the console for details.');
                }
            }
        });
    });


    // Profile Page
    if (window.location.pathname.endsWith("profile.html")) {
        let sessionToken = localStorage.getItem('session_token');
        let username = localStorage.getItem('username');

        if (!sessionToken || !username) {
            window.location.href = 'login.html';
        } else {
            $("#welcomeMessage").text(`Welcome, ${username}!`);
        }

        $("#profileForm").on("submit", function(e) {
            e.preventDefault();
            let formData = $(this).serialize() + '&session_token=' + sessionToken;
            $.ajax({
                url: 'php/update_profile.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    let res = JSON.parse(response);
                    if (res.status === 'success') {
                        alert("Profile updated successfully!");
                    } else {
                        alert("Profile updated successfully!");
                    }
                }
            });
        });
    }
});
